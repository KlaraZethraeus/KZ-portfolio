import { createContext } from 'react'

export const ImageSizeContext = createContext<number>(500)
