//updated
// import { NavLink } from 'react-router-dom'
// import styled from 'styled-components'
// import BillySsWork from './BillySsWork'
// import BillyAwWork from './BillyAwWork'
// import PkHighEnd from './PkHighEnd'
// import PhotoGallery from './PhotoGallery'
// import PkParis from './PkParis'
// import PkCountry from './PkCountry'
// import SvaMagazine from './SvaMagazine'
// import MalcomEditorial from './MalcomEditorial'
// import OdalisqueEditortial from './OdalisqueEditorial'
// import InstituteMagazine from './InstituteMagazine'

// const ImagePortfolio = () => {
//   return (
//     <Container>
//       <Header>{/* <Heading>{Img.name}</Heading> */}</Header>
//       <Content>
//         <Category>
//           <CategoryHeading>creative director</CategoryHeading>
//           {/* <CategorySubheading>billy and I</CategorySubheading> */}
//           <CategoryText>
//             <h3>billy and i</h3>
//             <p>S.S - 13</p>
//             <BillySsWork images={[]} />
//             <h3>billy and i</h3>
//             <p>A.W - 13</p>
//             <BillyAwWork images={[]} />
//           </CategoryText>
//         </Category>
//         <Category>
//           <CategoryHeading>editorial</CategoryHeading>
//           <CategoryText>
//             <h3>plaza kvinna</h3>
//             <p>cover</p>
//             <PkHighEnd images={[]} />
//             <h3>plaza kvinna</h3>
//             <p>paris</p>
//             {/* <PkParis /> */}

//             <h3>Plaza kvinna</h3>
//             <p>Denim</p>
//             {/* <PkCountry images={[]} /> */}
//             <h3>SVA magazin</h3>
//             <p>High end</p>
//             {/* <SvaMagazine images={[]} /> */}
//             <h3>seventh Man</h3>
//             <p>closer</p>
//             {/* <MalcomEditorial images={[]} /> */}
//             <h3>odalisque</h3>
//             <p>jewelry</p>
//             {/* <OdalisqueEditortial images={[]} /> */}
//             <h3>institute magazine</h3>
//             <p>glam</p>
//             {/* <InstituteMagazine images={[]} /> */}
//             <h3>DV mode</h3>
//             <p>Punk</p>
//           </CategoryText>
//         </Category>
//       </Content>
//     </Container>
//   )
// }
// const Container = styled.div`
//   display: flex;
//   /* flex-direction: column; */
//   align-items: center;
//   text-align: center;
// `

// const Header = styled.div``

// // const Heading = styled.h1`
// //   color: #333;
// // `

// const Content = styled.div`
//   margin-top: 0.5rem;
// `

// const Category = styled.div`
//   /* margin-top: 0.8rem; */
// `

// const CategoryHeading = styled.h2`
//   font-size: 0.6rem;
//   font-weight: 300;
//   margin-top: 0.5rem;
//   margin-bottom: 0.5rem;
// `

// // const CategorySubheading = styled.h3`
// //   font-size: 1rem;
// //   font-weight: bold;
// //   margin-top: 0.5rem;
// //   margin-bottom: 1rem;
// // `

// const CategoryText = styled.div`
//   h3 {
//     font-family: Ubuntu;
//     font-size: 1.3rem;
//     font-weight: 600;
//     margin-top: 0.5rem;
//     /* margin-bottom: 0.2rem; */
//   }

//   p {
//     font-weight: 600;
//     font-size: 0.8rem;
//     margin-bottom: -2.5rem;
//     margin-top: -1rem;
//   }
// `
// export default ImagePortfolio
