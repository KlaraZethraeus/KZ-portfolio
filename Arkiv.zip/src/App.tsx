import React, { createContext } from 'react'
import {
  createHashRouter,
  Outlet,
  RouterProvider,
  // useParams,
} from 'react-router-dom'
import { GapProvider } from './component/context/GapProvider'
import { GridImages } from './component/GridImages'
import { GapButton } from './component/GapButton'
import AboutMe from './component/AboutMe'
import InspirationGrid from './component/InspirationGrid'
import PortFolio from './component/PortFolio'
// import ImagePortfolio from './component/ImagePortfolio'
import HeaderMobile from './component/HeaderMobile'
import { SignupProvider } from './component/context/SignupContext'
import PhotoGallery from './component/PhotoGallery'

export const ImageSizeContext = createContext(500)
// export const setImageSizeContext = createContext(() => {})
// interface InspirationGridProps {
//   images: {
//     id: string
//     name: string
//     src: string
//   }[]
// }

// type ImageData = {
//   id: string
//   name: string
//   src: string
// }

function Root() {
  return (
    <>
      <HeaderMobile />
      <Outlet />
    </>
  )
}

function App() {
  const router = createHashRouter([
    {
      children: [
        {
          element: (
            <SignupProvider>
              <GapProvider>
                <GridImages />
                <GapButton />
              </GapProvider>
            </SignupProvider>
          ),
          path: '/',
        },
        { element: <PortFolio />, path: '/portfolio' },

        {
          element: <AboutMe />,
          path: '/aboutme',
        },
        {
          element: <InspirationGrid images={[]} />,
          path: '/inspiration',
        },
        {
          element: <PhotoGallery images={[]} />,
          path: '/PhotoGallery',
        },
        // {
        //   element: <ImagePortfolio />,
        //   path: '/ImagePortfolio',
        // },

        // useContext {
        //   element: (
        //     <ImageSizeContext.Provider value={imageSize}>
        //       <AboutMe />
        //     </ImageSizeContext.Provider>
        //   ),
        //   path: '/aboutme',
        // },
        //useParams
        // {
        //   element: <MySignupForm userName={useParams().userName} />,
        //   path: '/about/:userName',
        // },
      ],
      element: <Root />,
    },
  ])

  return <RouterProvider router={router} />
}
export default App
